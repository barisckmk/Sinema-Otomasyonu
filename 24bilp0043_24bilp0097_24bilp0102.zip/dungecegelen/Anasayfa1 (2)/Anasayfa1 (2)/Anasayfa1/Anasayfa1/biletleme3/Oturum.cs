﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anasayfa1
{
    public static class Oturum
    {
        public static int KullaniciID { get; set; } = 0;
        public static string KullaniciAdi { get; set; } = "Misafir";
        public static string AktifKullaniciMail { get; set; } = "";

        public static int RolID { get; set; }

        
    }
}
