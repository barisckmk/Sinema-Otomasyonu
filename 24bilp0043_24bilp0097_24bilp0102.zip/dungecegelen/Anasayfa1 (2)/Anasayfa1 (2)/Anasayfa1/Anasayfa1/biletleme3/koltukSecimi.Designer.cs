﻿namespace Anasayfa1
{
    partial class koltukSecimi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(koltukSecimi));
            this.pnlUstMenu = new System.Windows.Forms.Panel();
            this.pbBack = new System.Windows.Forms.PictureBox();
            this.pbClose = new System.Windows.Forms.PictureBox();
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlSteps = new System.Windows.Forms.Panel();
            this.pnlStep4 = new System.Windows.Forms.Panel();
            this.lblStepText4 = new System.Windows.Forms.Label();
            this.lblCircle4 = new System.Windows.Forms.Label();
            this.pnlStep3 = new System.Windows.Forms.Panel();
            this.lblStepText3 = new System.Windows.Forms.Label();
            this.lblCircle3 = new System.Windows.Forms.Label();
            this.pnlStep2 = new System.Windows.Forms.Panel();
            this.lblStepText2 = new System.Windows.Forms.Label();
            this.lblCircle2 = new System.Windows.Forms.Label();
            this.pnlStep1 = new System.Windows.Forms.Panel();
            this.lblStepText1 = new System.Windows.Forms.Label();
            this.lblCircle1 = new System.Windows.Forms.Label();
            this.lblLogoText = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.pnlKoltukAlan = new System.Windows.Forms.Panel();
            this.tblKoltuklar = new System.Windows.Forms.TableLayoutPanel();
            this.flpSatirSag = new System.Windows.Forms.FlowLayoutPanel();
            this.flpSatirSol = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlPerde = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlAlt = new System.Windows.Forms.Panel();
            this.flpLegend = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlBosLegend = new System.Windows.Forms.Panel();
            this.lblBosLegend = new System.Windows.Forms.Label();
            this.pnlDoluLegend = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlEngelliLegend = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlSecimLegend = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.pnlUstMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).BeginInit();
            this.pnlSteps.SuspendLayout();
            this.pnlStep4.SuspendLayout();
            this.pnlStep3.SuspendLayout();
            this.pnlStep2.SuspendLayout();
            this.pnlStep1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.pnlKoltukAlan.SuspendLayout();
            this.pnlPerde.SuspendLayout();
            this.pnlAlt.SuspendLayout();
            this.flpLegend.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlUstMenu
            // 
            this.pnlUstMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.pnlUstMenu.Controls.Add(this.pbBack);
            this.pnlUstMenu.Controls.Add(this.pbClose);
            this.pnlUstMenu.Controls.Add(this.btnDevamEt);
            this.pnlUstMenu.Controls.Add(this.label1);
            this.pnlUstMenu.Controls.Add(this.pnlSteps);
            this.pnlUstMenu.Controls.Add(this.lblLogoText);
            this.pnlUstMenu.Controls.Add(this.pbLogo);
            this.pnlUstMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlUstMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlUstMenu.Margin = new System.Windows.Forms.Padding(2);
            this.pnlUstMenu.Name = "pnlUstMenu";
            this.pnlUstMenu.Size = new System.Drawing.Size(1036, 156);
            this.pnlUstMenu.TabIndex = 2;
            this.pnlUstMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlUstMenu_Paint);
            // 
            // pbBack
            // 
            this.pbBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbBack.BackColor = System.Drawing.Color.Transparent;
            this.pbBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBack.Location = new System.Drawing.Point(965, 10);
            this.pbBack.Margin = new System.Windows.Forms.Padding(2);
            this.pbBack.Name = "pbBack";
            this.pbBack.Size = new System.Drawing.Size(24, 26);
            this.pbBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBack.TabIndex = 9;
            this.pbBack.TabStop = false;
            this.pbBack.Click += new System.EventHandler(this.pbBack_Click);
            // 
            // pbClose
            // 
            this.pbClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbClose.BackColor = System.Drawing.Color.Transparent;
            this.pbClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbClose.Location = new System.Drawing.Point(1004, 10);
            this.pbClose.Margin = new System.Windows.Forms.Padding(2);
            this.pbClose.Name = "pbClose";
            this.pbClose.Size = new System.Drawing.Size(24, 26);
            this.pbClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbClose.TabIndex = 7;
            this.pbClose.TabStop = false;
            this.pbClose.Click += new System.EventHandler(this.pbClose_Click);
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.BackColor = System.Drawing.Color.DarkRed;
            this.btnDevamEt.Enabled = false;
            this.btnDevamEt.ForeColor = System.Drawing.SystemColors.Control;
            this.btnDevamEt.Location = new System.Drawing.Point(926, 123);
            this.btnDevamEt.Margin = new System.Windows.Forms.Padding(2);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(90, 24);
            this.btnDevamEt.TabIndex = 1;
            this.btnDevamEt.Text = "Devam Et";
            this.btnDevamEt.UseVisualStyleBackColor = false;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 128);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(539, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Aşağıda listelenen koltuklardan boş olanları seçerek diğerine geçebilirsin";
            // 
            // pnlSteps
            // 
            this.pnlSteps.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlSteps.Controls.Add(this.pnlStep4);
            this.pnlSteps.Controls.Add(this.pnlStep3);
            this.pnlSteps.Controls.Add(this.pnlStep2);
            this.pnlSteps.Controls.Add(this.pnlStep1);
            this.pnlSteps.Location = new System.Drawing.Point(79, 53);
            this.pnlSteps.Margin = new System.Windows.Forms.Padding(2);
            this.pnlSteps.Name = "pnlSteps";
            this.pnlSteps.Size = new System.Drawing.Size(861, 49);
            this.pnlSteps.TabIndex = 2;
            // 
            // pnlStep4
            // 
            this.pnlStep4.Controls.Add(this.lblStepText4);
            this.pnlStep4.Controls.Add(this.lblCircle4);
            this.pnlStep4.Location = new System.Drawing.Point(584, 6);
            this.pnlStep4.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep4.Name = "pnlStep4";
            this.pnlStep4.Size = new System.Drawing.Size(149, 41);
            this.pnlStep4.TabIndex = 4;
            // 
            // lblStepText4
            // 
            this.lblStepText4.AutoSize = true;
            this.lblStepText4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText4.ForeColor = System.Drawing.Color.White;
            this.lblStepText4.Location = new System.Drawing.Point(28, 9);
            this.lblStepText4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText4.Name = "lblStepText4";
            this.lblStepText4.Size = new System.Drawing.Size(74, 24);
            this.lblStepText4.TabIndex = 4;
            this.lblStepText4.Text = "Ödeme";
            // 
            // lblCircle4
            // 
            this.lblCircle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle4.ForeColor = System.Drawing.Color.White;
            this.lblCircle4.Location = new System.Drawing.Point(2, 8);
            this.lblCircle4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle4.Name = "lblCircle4";
            this.lblCircle4.Size = new System.Drawing.Size(26, 29);
            this.lblCircle4.TabIndex = 3;
            this.lblCircle4.Text = "4";
            // 
            // pnlStep3
            // 
            this.pnlStep3.Controls.Add(this.lblStepText3);
            this.pnlStep3.Controls.Add(this.lblCircle3);
            this.pnlStep3.Location = new System.Drawing.Point(389, 7);
            this.pnlStep3.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep3.Name = "pnlStep3";
            this.pnlStep3.Size = new System.Drawing.Size(149, 41);
            this.pnlStep3.TabIndex = 4;
            // 
            // lblStepText3
            // 
            this.lblStepText3.AutoSize = true;
            this.lblStepText3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText3.ForeColor = System.Drawing.Color.White;
            this.lblStepText3.Location = new System.Drawing.Point(28, 9);
            this.lblStepText3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText3.Name = "lblStepText3";
            this.lblStepText3.Size = new System.Drawing.Size(123, 24);
            this.lblStepText3.TabIndex = 3;
            this.lblStepText3.Text = "Koltuk Seçimi";
            // 
            // lblCircle3
            // 
            this.lblCircle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle3.ForeColor = System.Drawing.Color.White;
            this.lblCircle3.Location = new System.Drawing.Point(2, 8);
            this.lblCircle3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle3.Name = "lblCircle3";
            this.lblCircle3.Size = new System.Drawing.Size(26, 29);
            this.lblCircle3.TabIndex = 2;
            this.lblCircle3.Text = "3";
            // 
            // pnlStep2
            // 
            this.pnlStep2.Controls.Add(this.lblStepText2);
            this.pnlStep2.Controls.Add(this.lblCircle2);
            this.pnlStep2.Location = new System.Drawing.Point(195, 7);
            this.pnlStep2.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep2.Name = "pnlStep2";
            this.pnlStep2.Size = new System.Drawing.Size(149, 41);
            this.pnlStep2.TabIndex = 3;
            // 
            // lblStepText2
            // 
            this.lblStepText2.AutoSize = true;
            this.lblStepText2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStepText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText2.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblStepText2.Location = new System.Drawing.Point(33, 10);
            this.lblStepText2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText2.Name = "lblStepText2";
            this.lblStepText2.Size = new System.Drawing.Size(81, 24);
            this.lblStepText2.TabIndex = 2;
            this.lblStepText2.Text = "Bilet Tipi";
            this.lblStepText2.Click += new System.EventHandler(this.lblStepText2_Click);
            // 
            // lblCircle2
            // 
            this.lblCircle2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCircle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle2.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblCircle2.Location = new System.Drawing.Point(2, 11);
            this.lblCircle2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle2.Name = "lblCircle2";
            this.lblCircle2.Size = new System.Drawing.Size(26, 29);
            this.lblCircle2.TabIndex = 1;
            this.lblCircle2.Text = "2";
            this.lblCircle2.Click += new System.EventHandler(this.lblCircle2_Click);
            // 
            // pnlStep1
            // 
            this.pnlStep1.Controls.Add(this.lblStepText1);
            this.pnlStep1.Controls.Add(this.lblCircle1);
            this.pnlStep1.Location = new System.Drawing.Point(0, 7);
            this.pnlStep1.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep1.Name = "pnlStep1";
            this.pnlStep1.Size = new System.Drawing.Size(149, 41);
            this.pnlStep1.TabIndex = 0;
            // 
            // lblStepText1
            // 
            this.lblStepText1.AutoSize = true;
            this.lblStepText1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStepText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText1.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblStepText1.Location = new System.Drawing.Point(27, 10);
            this.lblStepText1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText1.Name = "lblStepText1";
            this.lblStepText1.Size = new System.Drawing.Size(101, 24);
            this.lblStepText1.TabIndex = 1;
            this.lblStepText1.Text = "Seans Seç";
            this.lblStepText1.Click += new System.EventHandler(this.lblStepText1_Click);
            // 
            // lblCircle1
            // 
            this.lblCircle1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCircle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle1.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblCircle1.Location = new System.Drawing.Point(2, 10);
            this.lblCircle1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle1.Name = "lblCircle1";
            this.lblCircle1.Size = new System.Drawing.Size(26, 29);
            this.lblCircle1.TabIndex = 0;
            this.lblCircle1.Text = "1";
            this.lblCircle1.Click += new System.EventHandler(this.lblCircle1_Click);
            // 
            // lblLogoText
            // 
            this.lblLogoText.AutoSize = true;
            this.lblLogoText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogoText.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoText.ForeColor = System.Drawing.Color.White;
            this.lblLogoText.Location = new System.Drawing.Point(151, 13);
            this.lblLogoText.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLogoText.Name = "lblLogoText";
            this.lblLogoText.Size = new System.Drawing.Size(162, 37);
            this.lblLogoText.TabIndex = 1;
            this.lblLogoText.Text = "Işık Sinema";
            // 
            // pbLogo
            // 
            this.pbLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(79, 2);
            this.pbLogo.Margin = new System.Windows.Forms.Padding(2);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(52, 53);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo.TabIndex = 0;
            this.pbLogo.TabStop = false;
            // 
            // pnlKoltukAlan
            // 
            this.pnlKoltukAlan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlKoltukAlan.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlKoltukAlan.Controls.Add(this.tblKoltuklar);
            this.pnlKoltukAlan.Controls.Add(this.flpSatirSag);
            this.pnlKoltukAlan.Controls.Add(this.flpSatirSol);
            this.pnlKoltukAlan.Location = new System.Drawing.Point(0, 171);
            this.pnlKoltukAlan.Margin = new System.Windows.Forms.Padding(2);
            this.pnlKoltukAlan.Name = "pnlKoltukAlan";
            this.pnlKoltukAlan.Size = new System.Drawing.Size(1043, 361);
            this.pnlKoltukAlan.TabIndex = 3;
            this.pnlKoltukAlan.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlKoltukAlan_Paint);
            // 
            // tblKoltuklar
            // 
            this.tblKoltuklar.BackColor = System.Drawing.Color.Transparent;
            this.tblKoltuklar.ColumnCount = 14;
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tblKoltuklar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tblKoltuklar.Location = new System.Drawing.Point(188, 98);
            this.tblKoltuklar.Margin = new System.Windows.Forms.Padding(2);
            this.tblKoltuklar.Name = "tblKoltuklar";
            this.tblKoltuklar.RowCount = 8;
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblKoltuklar.Size = new System.Drawing.Size(660, 211);
            this.tblKoltuklar.TabIndex = 2;
            // 
            // flpSatirSag
            // 
            this.flpSatirSag.Location = new System.Drawing.Point(858, 98);
            this.flpSatirSag.Margin = new System.Windows.Forms.Padding(2);
            this.flpSatirSag.Name = "flpSatirSag";
            this.flpSatirSag.Size = new System.Drawing.Size(30, 211);
            this.flpSatirSag.TabIndex = 1;
            // 
            // flpSatirSol
            // 
            this.flpSatirSol.BackColor = System.Drawing.Color.Transparent;
            this.flpSatirSol.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpSatirSol.Location = new System.Drawing.Point(150, 98);
            this.flpSatirSol.Margin = new System.Windows.Forms.Padding(2);
            this.flpSatirSol.Name = "flpSatirSol";
            this.flpSatirSol.Size = new System.Drawing.Size(30, 211);
            this.flpSatirSol.TabIndex = 0;
            this.flpSatirSol.WrapContents = false;
            // 
            // pnlPerde
            // 
            this.pnlPerde.Controls.Add(this.label2);
            this.pnlPerde.Location = new System.Drawing.Point(179, 171);
            this.pnlPerde.Margin = new System.Windows.Forms.Padding(2);
            this.pnlPerde.Name = "pnlPerde";
            this.pnlPerde.Size = new System.Drawing.Size(675, 65);
            this.pnlPerde.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(317, 19);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "PERDE";
            // 
            // pnlAlt
            // 
            this.pnlAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.pnlAlt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAlt.Controls.Add(this.flpLegend);
            this.pnlAlt.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlAlt.Location = new System.Drawing.Point(0, 506);
            this.pnlAlt.Margin = new System.Windows.Forms.Padding(2);
            this.pnlAlt.Name = "pnlAlt";
            this.pnlAlt.Size = new System.Drawing.Size(1036, 65);
            this.pnlAlt.TabIndex = 4;
            // 
            // flpLegend
            // 
            this.flpLegend.BackColor = System.Drawing.Color.Transparent;
            this.flpLegend.Controls.Add(this.label3);
            this.flpLegend.Controls.Add(this.pnlBosLegend);
            this.flpLegend.Controls.Add(this.lblBosLegend);
            this.flpLegend.Controls.Add(this.pnlDoluLegend);
            this.flpLegend.Controls.Add(this.label4);
            this.flpLegend.Controls.Add(this.pnlEngelliLegend);
            this.flpLegend.Controls.Add(this.label5);
            this.flpLegend.Controls.Add(this.pnlSecimLegend);
            this.flpLegend.Controls.Add(this.label6);
            this.flpLegend.Location = new System.Drawing.Point(265, 28);
            this.flpLegend.Margin = new System.Windows.Forms.Padding(2);
            this.flpLegend.Name = "flpLegend";
            this.flpLegend.Size = new System.Drawing.Size(555, 32);
            this.flpLegend.TabIndex = 0;
            this.flpLegend.WrapContents = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(2, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 0);
            this.label3.TabIndex = 1;
            this.label3.Text = "label3";
            // 
            // pnlBosLegend
            // 
            this.pnlBosLegend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(176)))), ((int)(((byte)(52)))));
            this.pnlBosLegend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBosLegend.Location = new System.Drawing.Point(6, 7);
            this.pnlBosLegend.Margin = new System.Windows.Forms.Padding(2, 7, 8, 2);
            this.pnlBosLegend.Name = "pnlBosLegend";
            this.pnlBosLegend.Size = new System.Drawing.Size(18, 20);
            this.pnlBosLegend.TabIndex = 6;
            // 
            // lblBosLegend
            // 
            this.lblBosLegend.AutoSize = true;
            this.lblBosLegend.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBosLegend.ForeColor = System.Drawing.SystemColors.Control;
            this.lblBosLegend.Location = new System.Drawing.Point(32, 9);
            this.lblBosLegend.Margin = new System.Windows.Forms.Padding(0, 9, 15, 4);
            this.lblBosLegend.Name = "lblBosLegend";
            this.lblBosLegend.Size = new System.Drawing.Size(92, 15);
            this.lblBosLegend.TabIndex = 7;
            this.lblBosLegend.Text = "Boş Koltuklar";
            // 
            // pnlDoluLegend
            // 
            this.pnlDoluLegend.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlDoluLegend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDoluLegend.Location = new System.Drawing.Point(141, 7);
            this.pnlDoluLegend.Margin = new System.Windows.Forms.Padding(2, 7, 8, 2);
            this.pnlDoluLegend.Name = "pnlDoluLegend";
            this.pnlDoluLegend.Size = new System.Drawing.Size(18, 20);
            this.pnlDoluLegend.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(167, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(0, 9, 15, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Dolu Koltuklar";
            // 
            // pnlEngelliLegend
            // 
            this.pnlEngelliLegend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(180)))), ((int)(((byte)(220)))));
            this.pnlEngelliLegend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlEngelliLegend.Location = new System.Drawing.Point(282, 7);
            this.pnlEngelliLegend.Margin = new System.Windows.Forms.Padding(2, 7, 8, 2);
            this.pnlEngelliLegend.Name = "pnlEngelliLegend";
            this.pnlEngelliLegend.Size = new System.Drawing.Size(18, 20);
            this.pnlEngelliLegend.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(308, 9);
            this.label5.Margin = new System.Windows.Forms.Padding(0, 9, 15, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "Engelli Koltukları";
            // 
            // pnlSecimLegend
            // 
            this.pnlSecimLegend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(158)))), ((int)(((byte)(32)))));
            this.pnlSecimLegend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSecimLegend.Location = new System.Drawing.Point(442, 7);
            this.pnlSecimLegend.Margin = new System.Windows.Forms.Padding(2, 7, 8, 2);
            this.pnlSecimLegend.Name = "pnlSecimLegend";
            this.pnlSecimLegend.Size = new System.Drawing.Size(18, 20);
            this.pnlSecimLegend.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(468, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(0, 9, 15, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Seçiminiz";
            // 
            // koltukSecimi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1036, 571);
            this.ControlBox = false;
            this.Controls.Add(this.pnlAlt);
            this.Controls.Add(this.pnlPerde);
            this.Controls.Add(this.pnlKoltukAlan);
            this.Controls.Add(this.pnlUstMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "koltukSecimi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "koltukSecimi";
            this.Load += new System.EventHandler(this.koltukSecimi_Load);
            this.pnlUstMenu.ResumeLayout(false);
            this.pnlUstMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).EndInit();
            this.pnlSteps.ResumeLayout(false);
            this.pnlStep4.ResumeLayout(false);
            this.pnlStep4.PerformLayout();
            this.pnlStep3.ResumeLayout(false);
            this.pnlStep3.PerformLayout();
            this.pnlStep2.ResumeLayout(false);
            this.pnlStep2.PerformLayout();
            this.pnlStep1.ResumeLayout(false);
            this.pnlStep1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.pnlKoltukAlan.ResumeLayout(false);
            this.pnlPerde.ResumeLayout(false);
            this.pnlPerde.PerformLayout();
            this.pnlAlt.ResumeLayout(false);
            this.flpLegend.ResumeLayout(false);
            this.flpLegend.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlUstMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlSteps;
        private System.Windows.Forms.Panel pnlStep4;
        private System.Windows.Forms.Label lblStepText4;
        private System.Windows.Forms.Label lblCircle4;
        private System.Windows.Forms.Panel pnlStep3;
        private System.Windows.Forms.Label lblStepText3;
        private System.Windows.Forms.Label lblCircle3;
        private System.Windows.Forms.Panel pnlStep2;
        private System.Windows.Forms.Label lblStepText2;
        private System.Windows.Forms.Label lblCircle2;
        private System.Windows.Forms.Panel pnlStep1;
        private System.Windows.Forms.Label lblStepText1;
        private System.Windows.Forms.Label lblCircle1;
        private System.Windows.Forms.Label lblLogoText;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Panel pnlKoltukAlan;
        private System.Windows.Forms.Panel pnlPerde;
        private System.Windows.Forms.TableLayoutPanel tblKoltuklar;
        private System.Windows.Forms.FlowLayoutPanel flpSatirSag;
        private System.Windows.Forms.FlowLayoutPanel flpSatirSol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlAlt;
        private System.Windows.Forms.FlowLayoutPanel flpLegend;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlBosLegend;
        private System.Windows.Forms.Label lblBosLegend;
        private System.Windows.Forms.Panel pnlDoluLegend;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnlEngelliLegend;
        private System.Windows.Forms.Button btnDevamEt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlSecimLegend;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pbClose;
        private System.Windows.Forms.PictureBox pbBack;
    }
}