﻿namespace Anasayfa1
{
    partial class odeme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(odeme));
            this.pnlUstMenu = new System.Windows.Forms.Panel();
            this.pbBack = new System.Windows.Forms.PictureBox();
            this.pbClose = new System.Windows.Forms.PictureBox();
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlSteps = new System.Windows.Forms.Panel();
            this.pnlStep4 = new System.Windows.Forms.Panel();
            this.lblStepText4 = new System.Windows.Forms.Label();
            this.lblCircle4 = new System.Windows.Forms.Label();
            this.pnlStep3 = new System.Windows.Forms.Panel();
            this.lblStepText3 = new System.Windows.Forms.Label();
            this.lblCircle3 = new System.Windows.Forms.Label();
            this.pnlStep2 = new System.Windows.Forms.Panel();
            this.lblStepText2 = new System.Windows.Forms.Label();
            this.lblCircle2 = new System.Windows.Forms.Label();
            this.pnlStep1 = new System.Windows.Forms.Panel();
            this.lblStepText1 = new System.Windows.Forms.Label();
            this.lblCircle1 = new System.Windows.Forms.Label();
            this.lblLogoText = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.pnlBody = new System.Windows.Forms.Panel();
            this.pnlCard = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkKampanya = new System.Windows.Forms.CheckBox();
            this.chkKosullar = new System.Windows.Forms.CheckBox();
            this.pnlOdemeDetay = new System.Windows.Forms.Panel();
            this.lblBufeDetay = new System.Windows.Forms.Label();
            this.lblBiletDetay = new System.Windows.Forms.Label();
            this.lblToplamBaslik = new System.Windows.Forms.Label();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtAdSoyad = new System.Windows.Forms.TextBox();
            this.lblSure = new System.Windows.Forms.Label();
            this.pnlSureBar = new System.Windows.Forms.Label();
            this.lblOdemeBaslik = new System.Windows.Forms.Label();
            this.timerSure = new System.Windows.Forms.Timer(this.components);
            this.pnlUstMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).BeginInit();
            this.pnlSteps.SuspendLayout();
            this.pnlStep4.SuspendLayout();
            this.pnlStep3.SuspendLayout();
            this.pnlStep2.SuspendLayout();
            this.pnlStep1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.pnlBody.SuspendLayout();
            this.pnlCard.SuspendLayout();
            this.pnlOdemeDetay.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlUstMenu
            // 
            this.pnlUstMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.pnlUstMenu.Controls.Add(this.pbBack);
            this.pnlUstMenu.Controls.Add(this.pbClose);
            this.pnlUstMenu.Controls.Add(this.btnDevamEt);
            this.pnlUstMenu.Controls.Add(this.label1);
            this.pnlUstMenu.Controls.Add(this.pnlSteps);
            this.pnlUstMenu.Controls.Add(this.lblLogoText);
            this.pnlUstMenu.Controls.Add(this.pbLogo);
            this.pnlUstMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlUstMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlUstMenu.Name = "pnlUstMenu";
            this.pnlUstMenu.Size = new System.Drawing.Size(1381, 192);
            this.pnlUstMenu.TabIndex = 3;
            this.pnlUstMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlUstMenu_Paint);
            // 
            // pbBack
            // 
            this.pbBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbBack.BackColor = System.Drawing.Color.Transparent;
            this.pbBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBack.Location = new System.Drawing.Point(1291, 12);
            this.pbBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbBack.Name = "pbBack";
            this.pbBack.Size = new System.Drawing.Size(32, 32);
            this.pbBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBack.TabIndex = 10;
            this.pbBack.TabStop = false;
            this.pbBack.Click += new System.EventHandler(this.pbBack_Click);
            // 
            // pbClose
            // 
            this.pbClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbClose.BackColor = System.Drawing.Color.Transparent;
            this.pbClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbClose.Location = new System.Drawing.Point(1339, 12);
            this.pbClose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbClose.Name = "pbClose";
            this.pbClose.Size = new System.Drawing.Size(32, 32);
            this.pbClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbClose.TabIndex = 8;
            this.pbClose.TabStop = false;
            this.pbClose.Click += new System.EventHandler(this.pbClose_Click);
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.BackColor = System.Drawing.Color.DarkRed;
            this.btnDevamEt.Enabled = false;
            this.btnDevamEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevamEt.ForeColor = System.Drawing.SystemColors.Control;
            this.btnDevamEt.Location = new System.Drawing.Point(1235, 151);
            this.btnDevamEt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(120, 30);
            this.btnDevamEt.TabIndex = 1;
            this.btnDevamEt.Text = "Devam Et";
            this.btnDevamEt.UseVisualStyleBackColor = false;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1075, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Aşağıda listelenen bilet satın alma işleminizi bilgilerinizin doğruluna bakabilir" +
    " ve özleşmeyi onaylayarak ödemeye geçebilirsiniz";
            // 
            // pnlSteps
            // 
            this.pnlSteps.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlSteps.Controls.Add(this.pnlStep4);
            this.pnlSteps.Controls.Add(this.pnlStep3);
            this.pnlSteps.Controls.Add(this.pnlStep2);
            this.pnlSteps.Controls.Add(this.pnlStep1);
            this.pnlSteps.Location = new System.Drawing.Point(105, 65);
            this.pnlSteps.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlSteps.Name = "pnlSteps";
            this.pnlSteps.Size = new System.Drawing.Size(1148, 60);
            this.pnlSteps.TabIndex = 2;
            // 
            // pnlStep4
            // 
            this.pnlStep4.Controls.Add(this.lblStepText4);
            this.pnlStep4.Controls.Add(this.lblCircle4);
            this.pnlStep4.Location = new System.Drawing.Point(779, 7);
            this.pnlStep4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep4.Name = "pnlStep4";
            this.pnlStep4.Size = new System.Drawing.Size(199, 50);
            this.pnlStep4.TabIndex = 4;
            // 
            // lblStepText4
            // 
            this.lblStepText4.AutoSize = true;
            this.lblStepText4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText4.ForeColor = System.Drawing.Color.White;
            this.lblStepText4.Location = new System.Drawing.Point(37, 11);
            this.lblStepText4.Name = "lblStepText4";
            this.lblStepText4.Size = new System.Drawing.Size(94, 29);
            this.lblStepText4.TabIndex = 4;
            this.lblStepText4.Text = "Ödeme";
            // 
            // lblCircle4
            // 
            this.lblCircle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle4.ForeColor = System.Drawing.Color.White;
            this.lblCircle4.Location = new System.Drawing.Point(3, 10);
            this.lblCircle4.Name = "lblCircle4";
            this.lblCircle4.Size = new System.Drawing.Size(35, 36);
            this.lblCircle4.TabIndex = 3;
            this.lblCircle4.Text = "4";
            // 
            // pnlStep3
            // 
            this.pnlStep3.Controls.Add(this.lblStepText3);
            this.pnlStep3.Controls.Add(this.lblCircle3);
            this.pnlStep3.Location = new System.Drawing.Point(519, 9);
            this.pnlStep3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep3.Name = "pnlStep3";
            this.pnlStep3.Size = new System.Drawing.Size(199, 50);
            this.pnlStep3.TabIndex = 4;
            // 
            // lblStepText3
            // 
            this.lblStepText3.AutoSize = true;
            this.lblStepText3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStepText3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText3.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblStepText3.Location = new System.Drawing.Point(37, 11);
            this.lblStepText3.Name = "lblStepText3";
            this.lblStepText3.Size = new System.Drawing.Size(160, 29);
            this.lblStepText3.TabIndex = 3;
            this.lblStepText3.Text = "Koltuk Seçimi";
            this.lblStepText3.Click += new System.EventHandler(this.lblStepText3_Click);
            // 
            // lblCircle3
            // 
            this.lblCircle3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCircle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle3.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblCircle3.Location = new System.Drawing.Point(3, 10);
            this.lblCircle3.Name = "lblCircle3";
            this.lblCircle3.Size = new System.Drawing.Size(35, 36);
            this.lblCircle3.TabIndex = 2;
            this.lblCircle3.Text = "3";
            this.lblCircle3.Click += new System.EventHandler(this.lblCircle3_Click);
            // 
            // pnlStep2
            // 
            this.pnlStep2.Controls.Add(this.lblStepText2);
            this.pnlStep2.Controls.Add(this.lblCircle2);
            this.pnlStep2.Location = new System.Drawing.Point(260, 9);
            this.pnlStep2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep2.Name = "pnlStep2";
            this.pnlStep2.Size = new System.Drawing.Size(199, 50);
            this.pnlStep2.TabIndex = 3;
            // 
            // lblStepText2
            // 
            this.lblStepText2.AutoSize = true;
            this.lblStepText2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStepText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText2.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblStepText2.Location = new System.Drawing.Point(44, 12);
            this.lblStepText2.Name = "lblStepText2";
            this.lblStepText2.Size = new System.Drawing.Size(109, 29);
            this.lblStepText2.TabIndex = 2;
            this.lblStepText2.Text = "Bilet Tipi";
            this.lblStepText2.Click += new System.EventHandler(this.lblStepText2_Click);
            // 
            // lblCircle2
            // 
            this.lblCircle2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCircle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle2.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblCircle2.Location = new System.Drawing.Point(3, 14);
            this.lblCircle2.Name = "lblCircle2";
            this.lblCircle2.Size = new System.Drawing.Size(35, 36);
            this.lblCircle2.TabIndex = 1;
            this.lblCircle2.Text = "2";
            this.lblCircle2.Click += new System.EventHandler(this.lblCircle2_Click);
            // 
            // pnlStep1
            // 
            this.pnlStep1.Controls.Add(this.lblStepText1);
            this.pnlStep1.Controls.Add(this.lblCircle1);
            this.pnlStep1.Location = new System.Drawing.Point(0, 9);
            this.pnlStep1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep1.Name = "pnlStep1";
            this.pnlStep1.Size = new System.Drawing.Size(199, 50);
            this.pnlStep1.TabIndex = 0;
            // 
            // lblStepText1
            // 
            this.lblStepText1.AutoSize = true;
            this.lblStepText1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStepText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText1.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblStepText1.Location = new System.Drawing.Point(36, 12);
            this.lblStepText1.Name = "lblStepText1";
            this.lblStepText1.Size = new System.Drawing.Size(129, 29);
            this.lblStepText1.TabIndex = 1;
            this.lblStepText1.Text = "Seans Seç";
            this.lblStepText1.Click += new System.EventHandler(this.lblStepText1_Click);
            // 
            // lblCircle1
            // 
            this.lblCircle1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCircle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle1.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblCircle1.Location = new System.Drawing.Point(3, 12);
            this.lblCircle1.Name = "lblCircle1";
            this.lblCircle1.Size = new System.Drawing.Size(35, 36);
            this.lblCircle1.TabIndex = 0;
            this.lblCircle1.Text = "1";
            this.lblCircle1.Click += new System.EventHandler(this.lblCircle1_Click);
            // 
            // lblLogoText
            // 
            this.lblLogoText.AutoSize = true;
            this.lblLogoText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogoText.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoText.ForeColor = System.Drawing.Color.White;
            this.lblLogoText.Location = new System.Drawing.Point(201, 16);
            this.lblLogoText.Name = "lblLogoText";
            this.lblLogoText.Size = new System.Drawing.Size(195, 45);
            this.lblLogoText.TabIndex = 1;
            this.lblLogoText.Text = "Işık Sinema";
            // 
            // pbLogo
            // 
            this.pbLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(105, 2);
            this.pbLogo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(69, 65);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo.TabIndex = 0;
            this.pbLogo.TabStop = false;
            // 
            // pnlBody
            // 
            this.pnlBody.BackColor = System.Drawing.Color.Transparent;
            this.pnlBody.Controls.Add(this.pnlCard);
            this.pnlBody.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlBody.Location = new System.Drawing.Point(0, 187);
            this.pnlBody.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Size = new System.Drawing.Size(1381, 516);
            this.pnlBody.TabIndex = 4;
            this.pnlBody.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlBody_Paint);
            // 
            // pnlCard
            // 
            this.pnlCard.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.pnlCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCard.Controls.Add(this.panel1);
            this.pnlCard.Controls.Add(this.chkKampanya);
            this.pnlCard.Controls.Add(this.chkKosullar);
            this.pnlCard.Controls.Add(this.pnlOdemeDetay);
            this.pnlCard.Controls.Add(this.lblToplamBaslik);
            this.pnlCard.Controls.Add(this.txtTelefon);
            this.pnlCard.Controls.Add(this.txtEmail);
            this.pnlCard.Controls.Add(this.txtAdSoyad);
            this.pnlCard.Controls.Add(this.lblSure);
            this.pnlCard.Controls.Add(this.pnlSureBar);
            this.pnlCard.Controls.Add(this.lblOdemeBaslik);
            this.pnlCard.Location = new System.Drawing.Point(197, 27);
            this.pnlCard.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlCard.Name = "pnlCard";
            this.pnlCard.Size = new System.Drawing.Size(1025, 468);
            this.pnlCard.TabIndex = 0;
            this.pnlCard.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlCard_Paint);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(588, 263);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(37, 166);
            this.panel1.TabIndex = 10;
            // 
            // chkKampanya
            // 
            this.chkKampanya.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chkKampanya.ForeColor = System.Drawing.Color.White;
            this.chkKampanya.Location = new System.Drawing.Point(631, 338);
            this.chkKampanya.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkKampanya.Name = "chkKampanya";
            this.chkKampanya.Size = new System.Drawing.Size(389, 46);
            this.chkKampanya.TabIndex = 9;
            this.chkKampanya.Text = "E-Posta ve SMS gönderimleri aracılığıyla kampanyalardan haberdar olmak istiyorum." +
    "";
            this.chkKampanya.UseVisualStyleBackColor = true;
            // 
            // chkKosullar
            // 
            this.chkKosullar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chkKosullar.ForeColor = System.Drawing.Color.White;
            this.chkKosullar.Location = new System.Drawing.Point(631, 281);
            this.chkKosullar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkKosullar.Name = "chkKosullar";
            this.chkKosullar.Size = new System.Drawing.Size(376, 52);
            this.chkKosullar.TabIndex = 8;
            this.chkKosullar.Text = "Ön Bilgilendirme Koşulları\'nı ve Mesafeli Satış Sözleşmesi\'ni okudum, onaylıyorum" +
    ".";
            this.chkKosullar.UseVisualStyleBackColor = true;
            this.chkKosullar.CheckedChanged += new System.EventHandler(this.chkKosullar_CheckedChanged);
            // 
            // pnlOdemeDetay
            // 
            this.pnlOdemeDetay.AutoScroll = true;
            this.pnlOdemeDetay.BackColor = System.Drawing.Color.Transparent;
            this.pnlOdemeDetay.Controls.Add(this.lblBufeDetay);
            this.pnlOdemeDetay.Controls.Add(this.lblBiletDetay);
            this.pnlOdemeDetay.Location = new System.Drawing.Point(20, 297);
            this.pnlOdemeDetay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlOdemeDetay.Name = "pnlOdemeDetay";
            this.pnlOdemeDetay.Size = new System.Drawing.Size(592, 110);
            this.pnlOdemeDetay.TabIndex = 7;
            this.pnlOdemeDetay.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlOdemeDetay_Paint);
            // 
            // lblBufeDetay
            // 
            this.lblBufeDetay.AutoSize = true;
            this.lblBufeDetay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBufeDetay.ForeColor = System.Drawing.Color.Silver;
            this.lblBufeDetay.Location = new System.Drawing.Point(3, 54);
            this.lblBufeDetay.Name = "lblBufeDetay";
            this.lblBufeDetay.Size = new System.Drawing.Size(53, 20);
            this.lblBufeDetay.TabIndex = 1;
            this.lblBufeDetay.Text = "label2";
            this.lblBufeDetay.Click += new System.EventHandler(this.lblBufeDetay_Click);
            // 
            // lblBiletDetay
            // 
            this.lblBiletDetay.AutoSize = true;
            this.lblBiletDetay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBiletDetay.ForeColor = System.Drawing.Color.Silver;
            this.lblBiletDetay.Location = new System.Drawing.Point(3, 0);
            this.lblBiletDetay.Name = "lblBiletDetay";
            this.lblBiletDetay.Size = new System.Drawing.Size(53, 20);
            this.lblBiletDetay.TabIndex = 0;
            this.lblBiletDetay.Text = "label2";
            // 
            // lblToplamBaslik
            // 
            this.lblToplamBaslik.AutoSize = true;
            this.lblToplamBaslik.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamBaslik.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblToplamBaslik.Location = new System.Drawing.Point(20, 266);
            this.lblToplamBaslik.Name = "lblToplamBaslik";
            this.lblToplamBaslik.Size = new System.Drawing.Size(141, 25);
            this.lblToplamBaslik.TabIndex = 6;
            this.lblToplamBaslik.Text = "Toplam: 0 TL";
            this.lblToplamBaslik.Click += new System.EventHandler(this.lblToplamBaslik_Click);
            // 
            // txtTelefon
            // 
            this.txtTelefon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.txtTelefon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtTelefon.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtTelefon.Location = new System.Drawing.Point(20, 230);
            this.txtTelefon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.ReadOnly = true;
            this.txtTelefon.Size = new System.Drawing.Size(987, 27);
            this.txtTelefon.TabIndex = 5;
            this.txtTelefon.TabStop = false;
            this.txtTelefon.TextChanged += new System.EventHandler(this.txtTelefon_TextChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtEmail.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtEmail.Location = new System.Drawing.Point(20, 170);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(987, 27);
            this.txtEmail.TabIndex = 4;
            this.txtEmail.TabStop = false;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // txtAdSoyad
            // 
            this.txtAdSoyad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.txtAdSoyad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAdSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtAdSoyad.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtAdSoyad.Location = new System.Drawing.Point(20, 110);
            this.txtAdSoyad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdSoyad.Name = "txtAdSoyad";
            this.txtAdSoyad.ReadOnly = true;
            this.txtAdSoyad.Size = new System.Drawing.Size(987, 27);
            this.txtAdSoyad.TabIndex = 3;
            this.txtAdSoyad.TabStop = false;
            this.txtAdSoyad.TextChanged += new System.EventHandler(this.txtAdSoyad_TextChanged);
            // 
            // lblSure
            // 
            this.lblSure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(165)))), ((int)(((byte)(40)))));
            this.lblSure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSure.ForeColor = System.Drawing.SystemColors.Control;
            this.lblSure.Location = new System.Drawing.Point(353, 62);
            this.lblSure.Name = "lblSure";
            this.lblSure.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.lblSure.Size = new System.Drawing.Size(283, 23);
            this.lblSure.TabIndex = 2;
            this.lblSure.Text = "label2";
            this.lblSure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSure.Click += new System.EventHandler(this.lblSure_Click);
            // 
            // pnlSureBar
            // 
            this.pnlSureBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(165)))), ((int)(((byte)(40)))));
            this.pnlSureBar.Location = new System.Drawing.Point(-1, 55);
            this.pnlSureBar.Name = "pnlSureBar";
            this.pnlSureBar.Size = new System.Drawing.Size(1045, 34);
            this.pnlSureBar.TabIndex = 1;
            this.pnlSureBar.Click += new System.EventHandler(this.pnlSureBar_Click);
            // 
            // lblOdemeBaslik
            // 
            this.lblOdemeBaslik.AutoSize = true;
            this.lblOdemeBaslik.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOdemeBaslik.ForeColor = System.Drawing.Color.White;
            this.lblOdemeBaslik.Location = new System.Drawing.Point(20, 15);
            this.lblOdemeBaslik.Name = "lblOdemeBaslik";
            this.lblOdemeBaslik.Size = new System.Drawing.Size(99, 29);
            this.lblOdemeBaslik.TabIndex = 0;
            this.lblOdemeBaslik.Text = "Ödeme";
            // 
            // timerSure
            // 
            this.timerSure.Interval = 1000;
            this.timerSure.Tick += new System.EventHandler(this.timerSure_Tick);
            // 
            // odeme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClientSize = new System.Drawing.Size(1381, 703);
            this.ControlBox = false;
            this.Controls.Add(this.pnlBody);
            this.Controls.Add(this.pnlUstMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "odeme";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "odeme";
            this.Load += new System.EventHandler(this.odeme_Load);
            this.pnlUstMenu.ResumeLayout(false);
            this.pnlUstMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).EndInit();
            this.pnlSteps.ResumeLayout(false);
            this.pnlStep4.ResumeLayout(false);
            this.pnlStep4.PerformLayout();
            this.pnlStep3.ResumeLayout(false);
            this.pnlStep3.PerformLayout();
            this.pnlStep2.ResumeLayout(false);
            this.pnlStep2.PerformLayout();
            this.pnlStep1.ResumeLayout(false);
            this.pnlStep1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.pnlBody.ResumeLayout(false);
            this.pnlCard.ResumeLayout(false);
            this.pnlCard.PerformLayout();
            this.pnlOdemeDetay.ResumeLayout(false);
            this.pnlOdemeDetay.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlUstMenu;
        private System.Windows.Forms.Button btnDevamEt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlSteps;
        private System.Windows.Forms.Panel pnlStep4;
        private System.Windows.Forms.Label lblStepText4;
        private System.Windows.Forms.Label lblCircle4;
        private System.Windows.Forms.Panel pnlStep3;
        private System.Windows.Forms.Label lblStepText3;
        private System.Windows.Forms.Label lblCircle3;
        private System.Windows.Forms.Panel pnlStep2;
        private System.Windows.Forms.Label lblStepText2;
        private System.Windows.Forms.Label lblCircle2;
        private System.Windows.Forms.Panel pnlStep1;
        private System.Windows.Forms.Label lblStepText1;
        private System.Windows.Forms.Label lblCircle1;
        private System.Windows.Forms.Label lblLogoText;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.Panel pnlCard;
        private System.Windows.Forms.Label lblOdemeBaslik;
        private System.Windows.Forms.Label lblSure;
        private System.Windows.Forms.Label pnlSureBar;
        private System.Windows.Forms.Timer timerSure;
        private System.Windows.Forms.TextBox txtAdSoyad;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblToplamBaslik;
        private System.Windows.Forms.Panel pnlOdemeDetay;
        private System.Windows.Forms.Label lblBiletDetay;
        private System.Windows.Forms.CheckBox chkKampanya;
        private System.Windows.Forms.CheckBox chkKosullar;
        private System.Windows.Forms.Label lblBufeDetay;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbClose;
        private System.Windows.Forms.PictureBox pbBack;
    }
}