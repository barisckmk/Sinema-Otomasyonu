﻿namespace Anasayfa1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.pbBack = new System.Windows.Forms.PictureBox();
            this.pbClose = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.pnlSteps = new System.Windows.Forms.Panel();
            this.pnlStep4 = new System.Windows.Forms.Panel();
            this.lblStepText4 = new System.Windows.Forms.Label();
            this.lblCircle4 = new System.Windows.Forms.Label();
            this.pnlStep3 = new System.Windows.Forms.Panel();
            this.lblStepText3 = new System.Windows.Forms.Label();
            this.lblCircle3 = new System.Windows.Forms.Label();
            this.pnlStep2 = new System.Windows.Forms.Panel();
            this.lblStepText2 = new System.Windows.Forms.Label();
            this.lblCircle2 = new System.Windows.Forms.Label();
            this.pnlStep1 = new System.Windows.Forms.Panel();
            this.lblStepText1 = new System.Windows.Forms.Label();
            this.lblCircle1 = new System.Windows.Forms.Label();
            this.lblLogoText = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.pnlFilmler = new System.Windows.Forms.Panel();
            this.flpFilmler = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlTarihSeans = new System.Windows.Forms.Panel();
            this.flpSeanslar = new System.Windows.Forms.FlowLayoutPanel();
            this.flpTarihler = new System.Windows.Forms.FlowLayoutPanel();
            this.btnTarih1 = new System.Windows.Forms.Button();
            this.btnTarih2 = new System.Windows.Forms.Button();
            this.btnTarih3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlSalonlar = new System.Windows.Forms.Panel();
            this.flpSalonlar = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).BeginInit();
            this.pnlSteps.SuspendLayout();
            this.pnlStep4.SuspendLayout();
            this.pnlStep3.SuspendLayout();
            this.pnlStep2.SuspendLayout();
            this.pnlStep1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.pnlFilmler.SuspendLayout();
            this.pnlTarihSeans.SuspendLayout();
            this.flpTarihler.SuspendLayout();
            this.pnlSalonlar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.Controls.Add(this.pbBack);
            this.pnlHeader.Controls.Add(this.pbClose);
            this.pnlHeader.Controls.Add(this.label1);
            this.pnlHeader.Controls.Add(this.btnDevamEt);
            this.pnlHeader.Controls.Add(this.pnlSteps);
            this.pnlHeader.Controls.Add(this.lblLogoText);
            this.pnlHeader.Controls.Add(this.pbLogo);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Margin = new System.Windows.Forms.Padding(2);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1036, 156);
            this.pnlHeader.TabIndex = 0;
            this.pnlHeader.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlHeader_Paint);
            // 
            // pbBack
            // 
            this.pbBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbBack.BackColor = System.Drawing.Color.Transparent;
            this.pbBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBack.Location = new System.Drawing.Point(949, 10);
            this.pbBack.Margin = new System.Windows.Forms.Padding(2);
            this.pbBack.Name = "pbBack";
            this.pbBack.Size = new System.Drawing.Size(24, 26);
            this.pbBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBack.TabIndex = 9;
            this.pbBack.TabStop = false;
            this.pbBack.Click += new System.EventHandler(this.pbBack_Click);
            // 
            // pbClose
            // 
            this.pbClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbClose.BackColor = System.Drawing.Color.Transparent;
            this.pbClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbClose.Location = new System.Drawing.Point(992, 10);
            this.pbClose.Margin = new System.Windows.Forms.Padding(2);
            this.pbClose.Name = "pbClose";
            this.pbClose.Size = new System.Drawing.Size(24, 26);
            this.pbClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbClose.TabIndex = 6;
            this.pbClose.TabStop = false;
            this.pbClose.Click += new System.EventHandler(this.pbClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(76, 129);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(742, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Aşağıda listelenen film, salon ve seans seçeneklerinden tercihini yaparak diğer a" +
    "dımlara geçebilirsin.";
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDevamEt.BackColor = System.Drawing.Color.DarkRed;
            this.btnDevamEt.Enabled = false;
            this.btnDevamEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevamEt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDevamEt.ForeColor = System.Drawing.Color.White;
            this.btnDevamEt.Location = new System.Drawing.Point(883, 121);
            this.btnDevamEt.Margin = new System.Windows.Forms.Padding(2);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(90, 24);
            this.btnDevamEt.TabIndex = 3;
            this.btnDevamEt.Text = "Devam Et";
            this.btnDevamEt.UseVisualStyleBackColor = false;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // pnlSteps
            // 
            this.pnlSteps.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlSteps.Controls.Add(this.pnlStep4);
            this.pnlSteps.Controls.Add(this.pnlStep3);
            this.pnlSteps.Controls.Add(this.pnlStep2);
            this.pnlSteps.Controls.Add(this.pnlStep1);
            this.pnlSteps.Location = new System.Drawing.Point(79, 53);
            this.pnlSteps.Margin = new System.Windows.Forms.Padding(2);
            this.pnlSteps.Name = "pnlSteps";
            this.pnlSteps.Size = new System.Drawing.Size(796, 49);
            this.pnlSteps.TabIndex = 2;
            // 
            // pnlStep4
            // 
            this.pnlStep4.Controls.Add(this.lblStepText4);
            this.pnlStep4.Controls.Add(this.lblCircle4);
            this.pnlStep4.Location = new System.Drawing.Point(584, 6);
            this.pnlStep4.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep4.Name = "pnlStep4";
            this.pnlStep4.Size = new System.Drawing.Size(149, 41);
            this.pnlStep4.TabIndex = 4;
            // 
            // lblStepText4
            // 
            this.lblStepText4.AutoSize = true;
            this.lblStepText4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText4.ForeColor = System.Drawing.Color.White;
            this.lblStepText4.Location = new System.Drawing.Point(28, 9);
            this.lblStepText4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText4.Name = "lblStepText4";
            this.lblStepText4.Size = new System.Drawing.Size(74, 24);
            this.lblStepText4.TabIndex = 4;
            this.lblStepText4.Text = "Ödeme";
            // 
            // lblCircle4
            // 
            this.lblCircle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle4.ForeColor = System.Drawing.Color.White;
            this.lblCircle4.Location = new System.Drawing.Point(2, 8);
            this.lblCircle4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle4.Name = "lblCircle4";
            this.lblCircle4.Size = new System.Drawing.Size(26, 29);
            this.lblCircle4.TabIndex = 3;
            this.lblCircle4.Text = "4";
            // 
            // pnlStep3
            // 
            this.pnlStep3.Controls.Add(this.lblStepText3);
            this.pnlStep3.Controls.Add(this.lblCircle3);
            this.pnlStep3.Location = new System.Drawing.Point(389, 7);
            this.pnlStep3.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep3.Name = "pnlStep3";
            this.pnlStep3.Size = new System.Drawing.Size(149, 41);
            this.pnlStep3.TabIndex = 4;
            // 
            // lblStepText3
            // 
            this.lblStepText3.AutoSize = true;
            this.lblStepText3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText3.ForeColor = System.Drawing.Color.White;
            this.lblStepText3.Location = new System.Drawing.Point(28, 9);
            this.lblStepText3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText3.Name = "lblStepText3";
            this.lblStepText3.Size = new System.Drawing.Size(123, 24);
            this.lblStepText3.TabIndex = 3;
            this.lblStepText3.Text = "Koltuk Seçimi";
            // 
            // lblCircle3
            // 
            this.lblCircle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle3.ForeColor = System.Drawing.Color.White;
            this.lblCircle3.Location = new System.Drawing.Point(2, 8);
            this.lblCircle3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle3.Name = "lblCircle3";
            this.lblCircle3.Size = new System.Drawing.Size(26, 29);
            this.lblCircle3.TabIndex = 2;
            this.lblCircle3.Text = "3";
            // 
            // pnlStep2
            // 
            this.pnlStep2.Controls.Add(this.lblStepText2);
            this.pnlStep2.Controls.Add(this.lblCircle2);
            this.pnlStep2.Location = new System.Drawing.Point(195, 7);
            this.pnlStep2.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep2.Name = "pnlStep2";
            this.pnlStep2.Size = new System.Drawing.Size(149, 41);
            this.pnlStep2.TabIndex = 3;
            // 
            // lblStepText2
            // 
            this.lblStepText2.AutoSize = true;
            this.lblStepText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText2.ForeColor = System.Drawing.Color.White;
            this.lblStepText2.Location = new System.Drawing.Point(33, 10);
            this.lblStepText2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText2.Name = "lblStepText2";
            this.lblStepText2.Size = new System.Drawing.Size(81, 24);
            this.lblStepText2.TabIndex = 2;
            this.lblStepText2.Text = "Bilet Tipi";
            // 
            // lblCircle2
            // 
            this.lblCircle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle2.ForeColor = System.Drawing.Color.White;
            this.lblCircle2.Location = new System.Drawing.Point(2, 7);
            this.lblCircle2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle2.Name = "lblCircle2";
            this.lblCircle2.Size = new System.Drawing.Size(26, 29);
            this.lblCircle2.TabIndex = 1;
            this.lblCircle2.Text = "2";
            this.lblCircle2.Click += new System.EventHandler(this.label1_Click);
            // 
            // pnlStep1
            // 
            this.pnlStep1.Controls.Add(this.lblStepText1);
            this.pnlStep1.Controls.Add(this.lblCircle1);
            this.pnlStep1.Location = new System.Drawing.Point(0, 7);
            this.pnlStep1.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStep1.Name = "pnlStep1";
            this.pnlStep1.Size = new System.Drawing.Size(149, 41);
            this.pnlStep1.TabIndex = 0;
            // 
            // lblStepText1
            // 
            this.lblStepText1.AutoSize = true;
            this.lblStepText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText1.ForeColor = System.Drawing.Color.White;
            this.lblStepText1.Location = new System.Drawing.Point(27, 10);
            this.lblStepText1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStepText1.Name = "lblStepText1";
            this.lblStepText1.Size = new System.Drawing.Size(101, 24);
            this.lblStepText1.TabIndex = 1;
            this.lblStepText1.Text = "Seans Seç";
            // 
            // lblCircle1
            // 
            this.lblCircle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle1.ForeColor = System.Drawing.Color.White;
            this.lblCircle1.Location = new System.Drawing.Point(2, 10);
            this.lblCircle1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCircle1.Name = "lblCircle1";
            this.lblCircle1.Size = new System.Drawing.Size(26, 29);
            this.lblCircle1.TabIndex = 0;
            this.lblCircle1.Text = "1";
            // 
            // lblLogoText
            // 
            this.lblLogoText.AutoSize = true;
            this.lblLogoText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogoText.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoText.ForeColor = System.Drawing.Color.White;
            this.lblLogoText.Location = new System.Drawing.Point(151, 13);
            this.lblLogoText.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLogoText.Name = "lblLogoText";
            this.lblLogoText.Size = new System.Drawing.Size(162, 37);
            this.lblLogoText.TabIndex = 1;
            this.lblLogoText.Text = "Işık Sinema";
            this.lblLogoText.Click += new System.EventHandler(this.lblLogoText_Click);
            // 
            // pbLogo
            // 
            this.pbLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(79, 2);
            this.pbLogo.Margin = new System.Windows.Forms.Padding(2);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(52, 53);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo.TabIndex = 0;
            this.pbLogo.TabStop = false;
            // 
            // pnlFilmler
            // 
            this.pnlFilmler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.pnlFilmler.Controls.Add(this.flpFilmler);
            this.pnlFilmler.Controls.Add(this.label2);
            this.pnlFilmler.Location = new System.Drawing.Point(79, 161);
            this.pnlFilmler.Margin = new System.Windows.Forms.Padding(2);
            this.pnlFilmler.Name = "pnlFilmler";
            this.pnlFilmler.Size = new System.Drawing.Size(276, 382);
            this.pnlFilmler.TabIndex = 1;
            // 
            // flpFilmler
            // 
            this.flpFilmler.AutoScroll = true;
            this.flpFilmler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.flpFilmler.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpFilmler.Location = new System.Drawing.Point(1, 36);
            this.flpFilmler.Margin = new System.Windows.Forms.Padding(2);
            this.flpFilmler.Name = "flpFilmler";
            this.flpFilmler.Size = new System.Drawing.Size(275, 346);
            this.flpFilmler.TabIndex = 1;
            this.flpFilmler.WrapContents = false;
            this.flpFilmler.Paint += new System.Windows.Forms.PaintEventHandler(this.flpFilmler_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(2, 13);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Film Seçimi";
            // 
            // pnlTarihSeans
            // 
            this.pnlTarihSeans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.pnlTarihSeans.Controls.Add(this.flpSeanslar);
            this.pnlTarihSeans.Controls.Add(this.flpTarihler);
            this.pnlTarihSeans.Controls.Add(this.label4);
            this.pnlTarihSeans.Location = new System.Drawing.Point(697, 161);
            this.pnlTarihSeans.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTarihSeans.Name = "pnlTarihSeans";
            this.pnlTarihSeans.Size = new System.Drawing.Size(276, 382);
            this.pnlTarihSeans.TabIndex = 2;
            // 
            // flpSeanslar
            // 
            this.flpSeanslar.AutoScroll = true;
            this.flpSeanslar.BackColor = System.Drawing.Color.Transparent;
            this.flpSeanslar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpSeanslar.Location = new System.Drawing.Point(2, 115);
            this.flpSeanslar.Margin = new System.Windows.Forms.Padding(2);
            this.flpSeanslar.Name = "flpSeanslar";
            this.flpSeanslar.Size = new System.Drawing.Size(272, 287);
            this.flpSeanslar.TabIndex = 4;
            this.flpSeanslar.WrapContents = false;
            this.flpSeanslar.Paint += new System.Windows.Forms.PaintEventHandler(this.flpSeanslar_Paint);
            // 
            // flpTarihler
            // 
            this.flpTarihler.BackColor = System.Drawing.Color.Transparent;
            this.flpTarihler.Controls.Add(this.btnTarih2);
            this.flpTarihler.Controls.Add(this.btnTarih1);
            this.flpTarihler.Controls.Add(this.btnTarih3);
            this.flpTarihler.Location = new System.Drawing.Point(0, 36);
            this.flpTarihler.Margin = new System.Windows.Forms.Padding(2);
            this.flpTarihler.Name = "flpTarihler";
            this.flpTarihler.Size = new System.Drawing.Size(276, 65);
            this.flpTarihler.TabIndex = 3;
            this.flpTarihler.WrapContents = false;
            // 
            // btnTarih1
            // 
            this.btnTarih1.BackColor = System.Drawing.Color.DimGray;
            this.btnTarih1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTarih1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTarih1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTarih1.ForeColor = System.Drawing.Color.LawnGreen;
            this.btnTarih1.Location = new System.Drawing.Point(75, 2);
            this.btnTarih1.Margin = new System.Windows.Forms.Padding(2);
            this.btnTarih1.Name = "btnTarih1";
            this.btnTarih1.Size = new System.Drawing.Size(69, 29);
            this.btnTarih1.TabIndex = 0;
            this.btnTarih1.UseVisualStyleBackColor = false;
            this.btnTarih1.Click += new System.EventHandler(this.btnTarih1_Click);
            // 
            // btnTarih2
            // 
            this.btnTarih2.BackColor = System.Drawing.Color.DimGray;
            this.btnTarih2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTarih2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTarih2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTarih2.ForeColor = System.Drawing.Color.LawnGreen;
            this.btnTarih2.Location = new System.Drawing.Point(2, 2);
            this.btnTarih2.Margin = new System.Windows.Forms.Padding(2);
            this.btnTarih2.Name = "btnTarih2";
            this.btnTarih2.Size = new System.Drawing.Size(69, 29);
            this.btnTarih2.TabIndex = 1;
            this.btnTarih2.UseVisualStyleBackColor = false;
            this.btnTarih2.Click += new System.EventHandler(this.btnTarih2_Click);
            // 
            // btnTarih3
            // 
            this.btnTarih3.BackColor = System.Drawing.Color.DimGray;
            this.btnTarih3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTarih3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTarih3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTarih3.ForeColor = System.Drawing.Color.LawnGreen;
            this.btnTarih3.Location = new System.Drawing.Point(148, 2);
            this.btnTarih3.Margin = new System.Windows.Forms.Padding(2);
            this.btnTarih3.Name = "btnTarih3";
            this.btnTarih3.Size = new System.Drawing.Size(69, 29);
            this.btnTarih3.TabIndex = 2;
            this.btnTarih3.UseVisualStyleBackColor = false;
            this.btnTarih3.Click += new System.EventHandler(this.btnTarih3_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(11, 13);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tarih ve Seans ";
            // 
            // pnlSalonlar
            // 
            this.pnlSalonlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.pnlSalonlar.Controls.Add(this.flpSalonlar);
            this.pnlSalonlar.Controls.Add(this.label3);
            this.pnlSalonlar.Location = new System.Drawing.Point(389, 161);
            this.pnlSalonlar.Margin = new System.Windows.Forms.Padding(2);
            this.pnlSalonlar.Name = "pnlSalonlar";
            this.pnlSalonlar.Size = new System.Drawing.Size(276, 382);
            this.pnlSalonlar.TabIndex = 3;
            // 
            // flpSalonlar
            // 
            this.flpSalonlar.AutoScroll = true;
            this.flpSalonlar.BackColor = System.Drawing.Color.Gray;
            this.flpSalonlar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpSalonlar.Location = new System.Drawing.Point(1, 36);
            this.flpSalonlar.Margin = new System.Windows.Forms.Padding(2);
            this.flpSalonlar.Name = "flpSalonlar";
            this.flpSalonlar.Size = new System.Drawing.Size(276, 369);
            this.flpSalonlar.TabIndex = 2;
            this.flpSalonlar.WrapContents = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(15, 13);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Salon Seçimi";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.ClientSize = new System.Drawing.Size(1036, 571);
            this.ControlBox = false;
            this.Controls.Add(this.pnlSalonlar);
            this.Controls.Add(this.pnlTarihSeans);
            this.Controls.Add(this.pnlFilmler);
            this.Controls.Add(this.pnlHeader);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IşıkSinema";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).EndInit();
            this.pnlSteps.ResumeLayout(false);
            this.pnlStep4.ResumeLayout(false);
            this.pnlStep4.PerformLayout();
            this.pnlStep3.ResumeLayout(false);
            this.pnlStep3.PerformLayout();
            this.pnlStep2.ResumeLayout(false);
            this.pnlStep2.PerformLayout();
            this.pnlStep1.ResumeLayout(false);
            this.pnlStep1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.pnlFilmler.ResumeLayout(false);
            this.pnlFilmler.PerformLayout();
            this.pnlTarihSeans.ResumeLayout(false);
            this.flpTarihler.ResumeLayout(false);
            this.pnlSalonlar.ResumeLayout(false);
            this.pnlSalonlar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblLogoText;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Panel pnlSteps;
        private System.Windows.Forms.Panel pnlStep4;
        private System.Windows.Forms.Panel pnlStep3;
        private System.Windows.Forms.Panel pnlStep2;
        private System.Windows.Forms.Panel pnlStep1;
        private System.Windows.Forms.Label lblCircle1;
        private System.Windows.Forms.Label lblStepText1;
        private System.Windows.Forms.Label lblStepText2;
        private System.Windows.Forms.Label lblCircle2;
        private System.Windows.Forms.Label lblCircle4;
        private System.Windows.Forms.Label lblStepText3;
        private System.Windows.Forms.Label lblCircle3;
        private System.Windows.Forms.Label lblStepText4;
        private System.Windows.Forms.Button btnDevamEt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlFilmler;
        private System.Windows.Forms.Panel pnlTarihSeans;
        private System.Windows.Forms.Panel pnlSalonlar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.FlowLayoutPanel flpFilmler;
        private System.Windows.Forms.FlowLayoutPanel flpSalonlar;
        private System.Windows.Forms.FlowLayoutPanel flpTarihler;
        private System.Windows.Forms.FlowLayoutPanel flpSeanslar;
        private System.Windows.Forms.Button btnTarih1;
        private System.Windows.Forms.Button btnTarih2;
        private System.Windows.Forms.Button btnTarih3;
        private System.Windows.Forms.PictureBox pbClose;
        private System.Windows.Forms.PictureBox pbBack;
    }
}

