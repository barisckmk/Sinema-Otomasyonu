﻿namespace Anasayfa1
{
    partial class biletAlımVeBufe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(biletAlımVeBufe));
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.pbBack = new System.Windows.Forms.PictureBox();
            this.pbClose = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlSteps = new System.Windows.Forms.Panel();
            this.pnlStep4 = new System.Windows.Forms.Panel();
            this.lblStepText4 = new System.Windows.Forms.Label();
            this.lblCircle4 = new System.Windows.Forms.Label();
            this.pnlStep3 = new System.Windows.Forms.Panel();
            this.lblStepText3 = new System.Windows.Forms.Label();
            this.lblCircle3 = new System.Windows.Forms.Label();
            this.pnlStep2 = new System.Windows.Forms.Panel();
            this.lblStepText2 = new System.Windows.Forms.Label();
            this.lblCircle2 = new System.Windows.Forms.Label();
            this.pnlStep1 = new System.Windows.Forms.Panel();
            this.lblStepText1 = new System.Windows.Forms.Label();
            this.lblCircle1 = new System.Windows.Forms.Label();
            this.lblLogoText = new System.Windows.Forms.Label();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.pnlContent = new System.Windows.Forms.Panel();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.pnlToplam = new System.Windows.Forms.Panel();
            this.lblToplamUcret = new System.Windows.Forms.Label();
            this.flpBufe = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.flpBiletTipleri = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).BeginInit();
            this.pnlSteps.SuspendLayout();
            this.pnlStep4.SuspendLayout();
            this.pnlStep3.SuspendLayout();
            this.pnlStep2.SuspendLayout();
            this.pnlStep1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.pnlContent.SuspendLayout();
            this.pnlToplam.SuspendLayout();
            this.flpBufe.SuspendLayout();
            this.flpBiletTipleri.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.pnlHeader.Controls.Add(this.pbBack);
            this.pnlHeader.Controls.Add(this.pbClose);
            this.pnlHeader.Controls.Add(this.label1);
            this.pnlHeader.Controls.Add(this.pnlSteps);
            this.pnlHeader.Controls.Add(this.lblLogoText);
            this.pnlHeader.Controls.Add(this.pbLogo);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1381, 192);
            this.pnlHeader.TabIndex = 1;
            this.pnlHeader.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlHeader_Paint);
            // 
            // pbBack
            // 
            this.pbBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbBack.BackColor = System.Drawing.Color.Transparent;
            this.pbBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBack.Location = new System.Drawing.Point(1293, 12);
            this.pbBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbBack.Name = "pbBack";
            this.pbBack.Size = new System.Drawing.Size(32, 32);
            this.pbBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBack.TabIndex = 8;
            this.pbBack.TabStop = false;
            this.pbBack.Click += new System.EventHandler(this.pbBack_Click);
            // 
            // pbClose
            // 
            this.pbClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbClose.BackColor = System.Drawing.Color.Transparent;
            this.pbClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbClose.Location = new System.Drawing.Point(1339, 12);
            this.pbClose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbClose.Name = "pbClose";
            this.pbClose.Size = new System.Drawing.Size(32, 32);
            this.pbClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbClose.TabIndex = 7;
            this.pbClose.TabStop = false;
            this.pbClose.Click += new System.EventHandler(this.pbClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(101, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1053, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Aşağıda listelenen bilet satın alma işleminizi ve yiyecek içecek seçeneklerinden " +
    "tercihini yaparak diğer adımlara geçebilirsin";
            // 
            // pnlSteps
            // 
            this.pnlSteps.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlSteps.Controls.Add(this.pnlStep4);
            this.pnlSteps.Controls.Add(this.pnlStep3);
            this.pnlSteps.Controls.Add(this.pnlStep2);
            this.pnlSteps.Controls.Add(this.pnlStep1);
            this.pnlSteps.Location = new System.Drawing.Point(105, 65);
            this.pnlSteps.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlSteps.Name = "pnlSteps";
            this.pnlSteps.Size = new System.Drawing.Size(1148, 60);
            this.pnlSteps.TabIndex = 2;
            // 
            // pnlStep4
            // 
            this.pnlStep4.Controls.Add(this.lblStepText4);
            this.pnlStep4.Controls.Add(this.lblCircle4);
            this.pnlStep4.Location = new System.Drawing.Point(779, 7);
            this.pnlStep4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep4.Name = "pnlStep4";
            this.pnlStep4.Size = new System.Drawing.Size(199, 50);
            this.pnlStep4.TabIndex = 4;
            // 
            // lblStepText4
            // 
            this.lblStepText4.AutoSize = true;
            this.lblStepText4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText4.ForeColor = System.Drawing.Color.White;
            this.lblStepText4.Location = new System.Drawing.Point(37, 11);
            this.lblStepText4.Name = "lblStepText4";
            this.lblStepText4.Size = new System.Drawing.Size(94, 29);
            this.lblStepText4.TabIndex = 4;
            this.lblStepText4.Text = "Ödeme";
            // 
            // lblCircle4
            // 
            this.lblCircle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle4.ForeColor = System.Drawing.Color.White;
            this.lblCircle4.Location = new System.Drawing.Point(3, 10);
            this.lblCircle4.Name = "lblCircle4";
            this.lblCircle4.Size = new System.Drawing.Size(35, 36);
            this.lblCircle4.TabIndex = 3;
            this.lblCircle4.Text = "4";
            // 
            // pnlStep3
            // 
            this.pnlStep3.Controls.Add(this.lblStepText3);
            this.pnlStep3.Controls.Add(this.lblCircle3);
            this.pnlStep3.Location = new System.Drawing.Point(519, 9);
            this.pnlStep3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep3.Name = "pnlStep3";
            this.pnlStep3.Size = new System.Drawing.Size(199, 50);
            this.pnlStep3.TabIndex = 4;
            // 
            // lblStepText3
            // 
            this.lblStepText3.AutoSize = true;
            this.lblStepText3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText3.ForeColor = System.Drawing.Color.White;
            this.lblStepText3.Location = new System.Drawing.Point(37, 11);
            this.lblStepText3.Name = "lblStepText3";
            this.lblStepText3.Size = new System.Drawing.Size(160, 29);
            this.lblStepText3.TabIndex = 3;
            this.lblStepText3.Text = "Koltuk Seçimi";
            // 
            // lblCircle3
            // 
            this.lblCircle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle3.ForeColor = System.Drawing.Color.White;
            this.lblCircle3.Location = new System.Drawing.Point(3, 10);
            this.lblCircle3.Name = "lblCircle3";
            this.lblCircle3.Size = new System.Drawing.Size(35, 36);
            this.lblCircle3.TabIndex = 2;
            this.lblCircle3.Text = "3";
            // 
            // pnlStep2
            // 
            this.pnlStep2.Controls.Add(this.lblStepText2);
            this.pnlStep2.Controls.Add(this.lblCircle2);
            this.pnlStep2.Location = new System.Drawing.Point(260, 9);
            this.pnlStep2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep2.Name = "pnlStep2";
            this.pnlStep2.Size = new System.Drawing.Size(199, 50);
            this.pnlStep2.TabIndex = 3;
            // 
            // lblStepText2
            // 
            this.lblStepText2.AutoSize = true;
            this.lblStepText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText2.ForeColor = System.Drawing.Color.White;
            this.lblStepText2.Location = new System.Drawing.Point(44, 12);
            this.lblStepText2.Name = "lblStepText2";
            this.lblStepText2.Size = new System.Drawing.Size(109, 29);
            this.lblStepText2.TabIndex = 2;
            this.lblStepText2.Text = "Bilet Tipi";
            // 
            // lblCircle2
            // 
            this.lblCircle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle2.ForeColor = System.Drawing.Color.White;
            this.lblCircle2.Location = new System.Drawing.Point(3, 14);
            this.lblCircle2.Name = "lblCircle2";
            this.lblCircle2.Size = new System.Drawing.Size(35, 36);
            this.lblCircle2.TabIndex = 1;
            this.lblCircle2.Text = "2";
            // 
            // pnlStep1
            // 
            this.pnlStep1.Controls.Add(this.lblStepText1);
            this.pnlStep1.Controls.Add(this.lblCircle1);
            this.pnlStep1.Location = new System.Drawing.Point(0, 9);
            this.pnlStep1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlStep1.Name = "pnlStep1";
            this.pnlStep1.Size = new System.Drawing.Size(199, 50);
            this.pnlStep1.TabIndex = 0;
            // 
            // lblStepText1
            // 
            this.lblStepText1.AutoSize = true;
            this.lblStepText1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStepText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStepText1.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblStepText1.Location = new System.Drawing.Point(36, 12);
            this.lblStepText1.Name = "lblStepText1";
            this.lblStepText1.Size = new System.Drawing.Size(129, 29);
            this.lblStepText1.TabIndex = 1;
            this.lblStepText1.Text = "Seans Seç";
            this.lblStepText1.Click += new System.EventHandler(this.lblStepText1_Click);
            // 
            // lblCircle1
            // 
            this.lblCircle1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCircle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCircle1.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblCircle1.Location = new System.Drawing.Point(3, 12);
            this.lblCircle1.Name = "lblCircle1";
            this.lblCircle1.Size = new System.Drawing.Size(35, 36);
            this.lblCircle1.TabIndex = 0;
            this.lblCircle1.Text = "1";
            this.lblCircle1.Click += new System.EventHandler(this.lblCircle1_Click);
            // 
            // lblLogoText
            // 
            this.lblLogoText.AutoSize = true;
            this.lblLogoText.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLogoText.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoText.ForeColor = System.Drawing.Color.White;
            this.lblLogoText.Location = new System.Drawing.Point(201, 16);
            this.lblLogoText.Name = "lblLogoText";
            this.lblLogoText.Size = new System.Drawing.Size(195, 45);
            this.lblLogoText.TabIndex = 1;
            this.lblLogoText.Text = "Işık Sinema";
            // 
            // pbLogo
            // 
            this.pbLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbLogo.Image")));
            this.pbLogo.Location = new System.Drawing.Point(105, 2);
            this.pbLogo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(69, 65);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo.TabIndex = 0;
            this.pbLogo.TabStop = false;
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDevamEt.BackColor = System.Drawing.Color.DarkRed;
            this.btnDevamEt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDevamEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevamEt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDevamEt.ForeColor = System.Drawing.Color.White;
            this.btnDevamEt.Location = new System.Drawing.Point(1021, 7);
            this.btnDevamEt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(121, 30);
            this.btnDevamEt.TabIndex = 3;
            this.btnDevamEt.Text = "Devam Et";
            this.btnDevamEt.UseVisualStyleBackColor = false;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // pnlContent
            // 
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlContent.Controls.Add(this.btnLeft);
            this.pnlContent.Controls.Add(this.btnRight);
            this.pnlContent.Controls.Add(this.pnlToplam);
            this.pnlContent.Controls.Add(this.flpBufe);
            this.pnlContent.Controls.Add(this.flpBiletTipleri);
            this.pnlContent.ForeColor = System.Drawing.Color.Black;
            this.pnlContent.Location = new System.Drawing.Point(0, 192);
            this.pnlContent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.Size = new System.Drawing.Size(1381, 514);
            this.pnlContent.TabIndex = 2;
            this.pnlContent.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlContent_Paint);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.Color.Maroon;
            this.btnLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnLeft.Location = new System.Drawing.Point(13, 335);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(40, 39);
            this.btnLeft.TabIndex = 7;
            this.btnLeft.Text = "<";
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.Maroon;
            this.btnRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRight.Location = new System.Drawing.Point(1285, 335);
            this.btnRight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(40, 39);
            this.btnRight.TabIndex = 8;
            this.btnRight.Text = ">";
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // pnlToplam
            // 
            this.pnlToplam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.pnlToplam.Controls.Add(this.btnDevamEt);
            this.pnlToplam.Controls.Add(this.lblToplamUcret);
            this.pnlToplam.Location = new System.Drawing.Point(35, 6);
            this.pnlToplam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnlToplam.Name = "pnlToplam";
            this.pnlToplam.Size = new System.Drawing.Size(1269, 50);
            this.pnlToplam.TabIndex = 6;
            this.pnlToplam.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlToplam_Paint);
            // 
            // lblToplamUcret
            // 
            this.lblToplamUcret.BackColor = System.Drawing.Color.Transparent;
            this.lblToplamUcret.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamUcret.ForeColor = System.Drawing.Color.LawnGreen;
            this.lblToplamUcret.Location = new System.Drawing.Point(845, 2);
            this.lblToplamUcret.Name = "lblToplamUcret";
            this.lblToplamUcret.Size = new System.Drawing.Size(147, 46);
            this.lblToplamUcret.TabIndex = 4;
            this.lblToplamUcret.Text = "Toplam: 0 TL";
            this.lblToplamUcret.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblToplamUcret.Click += new System.EventHandler(this.lblToplamUcret_Click);
            // 
            // flpBufe
            // 
            this.flpBufe.AutoScroll = true;
            this.flpBufe.BackColor = System.Drawing.Color.Transparent;
            this.flpBufe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpBufe.Controls.Add(this.label3);
            this.flpBufe.Location = new System.Drawing.Point(27, 249);
            this.flpBufe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flpBufe.Name = "flpBufe";
            this.flpBufe.Size = new System.Drawing.Size(1301, 251);
            this.flpBufe.TabIndex = 5;
            this.flpBufe.WrapContents = false;
            this.flpBufe.Paint += new System.Windows.Forms.PaintEventHandler(this.flpBufe_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "Büfe";
            // 
            // flpBiletTipleri
            // 
            this.flpBiletTipleri.BackColor = System.Drawing.Color.Transparent;
            this.flpBiletTipleri.Controls.Add(this.label2);
            this.flpBiletTipleri.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpBiletTipleri.Location = new System.Drawing.Point(27, 63);
            this.flpBiletTipleri.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flpBiletTipleri.Name = "flpBiletTipleri";
            this.flpBiletTipleri.Size = new System.Drawing.Size(1300, 170);
            this.flpBiletTipleri.TabIndex = 4;
            this.flpBiletTipleri.WrapContents = false;
            this.flpBiletTipleri.Paint += new System.Windows.Forms.PaintEventHandler(this.flpBiletTipleri_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bilet Seçimi";
            // 
            // biletAlımVeBufe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1381, 703);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "biletAlımVeBufe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "biletAlımVeBufe";
            this.Load += new System.EventHandler(this.biletAlımVeBufe_Load);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbClose)).EndInit();
            this.pnlSteps.ResumeLayout(false);
            this.pnlStep4.ResumeLayout(false);
            this.pnlStep4.PerformLayout();
            this.pnlStep3.ResumeLayout(false);
            this.pnlStep3.PerformLayout();
            this.pnlStep2.ResumeLayout(false);
            this.pnlStep2.PerformLayout();
            this.pnlStep1.ResumeLayout(false);
            this.pnlStep1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.pnlContent.ResumeLayout(false);
            this.pnlToplam.ResumeLayout(false);
            this.flpBufe.ResumeLayout(false);
            this.flpBufe.PerformLayout();
            this.flpBiletTipleri.ResumeLayout(false);
            this.flpBiletTipleri.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDevamEt;
        private System.Windows.Forms.Panel pnlSteps;
        private System.Windows.Forms.Panel pnlStep4;
        private System.Windows.Forms.Label lblStepText4;
        private System.Windows.Forms.Label lblCircle4;
        private System.Windows.Forms.Panel pnlStep3;
        private System.Windows.Forms.Label lblStepText3;
        private System.Windows.Forms.Label lblCircle3;
        private System.Windows.Forms.Panel pnlStep2;
        private System.Windows.Forms.Label lblStepText2;
        private System.Windows.Forms.Label lblCircle2;
        private System.Windows.Forms.Panel pnlStep1;
        private System.Windows.Forms.Label lblStepText1;
        private System.Windows.Forms.Label lblCircle1;
        private System.Windows.Forms.Label lblLogoText;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.Panel pnlContent;
        private System.Windows.Forms.FlowLayoutPanel flpBiletTipleri;
        private System.Windows.Forms.FlowLayoutPanel flpBufe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlToplam;
        private System.Windows.Forms.Label lblToplamUcret;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.PictureBox pbClose;
        private System.Windows.Forms.PictureBox pbBack;
    }
}